import * as THREE from 'three';

const MOVES = {
  light: { dur: .38, hitAt: .45, dmg: 12, range: 2.6, arc: 1.9, cd: .05 },
  heavy: { dur: .8, hitAt: .55, dmg: 32, range: 3.4, arc: 2.6, cd: 1.4 },
  skill: { dur: .6, hitAt: .3, dmg: 26, range: 6, arc: Math.PI * 2, cd: 6 }
};

export class Combat {
  constructor(scene, world, player, hud, camera) {
    Object.assign(this, { scene, world, player, hud, camera }); this.cur = null; this.attackP = 0; this.cd = { light: 0, heavy: 0, skill: 0 };
    this.combo = 0; this.comboT = 0; this.buffer = null; this.faceTo = null; this.moveScale = 1; this.fx = [];
  }
  cdFrac(n) { return n === 'skill' ? this.cd.skill / MOVES.skill.cd : n === 'heavy' ? this.cd.heavy / MOVES.heavy.cd : 0; }
  request(name) {
    const p = this.player; if (p.dead || p.dodgeT > 0) return;
    if (this.cur) { if (this.cur.t > this.cur.m.dur * .5) this.buffer = name; return; }   // буфер ввода
    if (this.cd[name] > 0) return;
    const m = MOVES[name]; this.cur = { name, m, t: 0, hit: false, mult: name === 'light' ? 1 + .2 * this.combo : 1 }; this.cd[name] = m.cd;
    if (name === 'light') { this.combo = (this.combo + 1) % 3; this.comboT = .9; }
    let best = null, bd = 8;   // автонаведение на ближайшую цель
    for (const t of this.world.targets) if (t.alive) { const d = Math.hypot(t.x - p.pos.x, t.z - p.pos.z); if (d < bd) { bd = d; best = t; } }
    this.faceTo = best ? Math.atan2(best.x - p.pos.x, best.z - p.pos.z) : null;
    if (this.faceTo === null) this.faceTo = p.facing;
  }
  update(dt) {
    for (const k in this.cd) this.cd[k] = Math.max(0, this.cd[k] - dt);
    if ((this.comboT -= dt) < 0) this.combo = 0;
    if (this.cur) {
      const c = this.cur; c.t += dt; this.attackP = c.t / c.m.dur; this.moveScale = c.name === 'heavy' && this.attackP < c.m.hitAt ? .15 : .35;
      if (!c.hit && this.attackP >= c.m.hitAt) { c.hit = true; this._strike(c); }
      if (c.t >= c.m.dur) { this.cur = null; this.faceTo = null; this.moveScale = 1; this.attackP = 0; const b = this.buffer; this.buffer = null; if (b) this.request(b); }
    }
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]; f.life -= dt; f.mesh.material.opacity = Math.max(0, f.life / .25) * .8; f.mesh.scale.setScalar(1 + (.25 - f.life) * .6);
      if (f.life <= 0) { this.scene.remove(f.mesh); f.mesh.geometry.dispose(); f.mesh.material.dispose(); this.fx.splice(i, 1); }
    }
  }
  _strike({ m, mult }) {
    const p = this.player, f = this.faceTo ?? p.facing, fx = Math.sin(f), fz = Math.cos(f), full = m.arc >= Math.PI * 2;
    const g = new THREE.RingGeometry(m.range * .45, m.range, 32, 1, full ? 0 : f - Math.PI / 2 - m.arc / 2, full ? Math.PI * 2 : m.arc);
    const mesh = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0xb99cff, transparent: true, opacity: .8, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    mesh.rotation.x = -Math.PI / 2; mesh.position.set(p.pos.x, p.pos.y + .2, p.pos.z); this.scene.add(mesh); this.fx.push({ mesh, life: .25 });
    for (const t of this.world.targets) {
      if (!t.alive) continue; const dx = t.x - p.pos.x, dz = t.z - p.pos.z, d = Math.hypot(dx, dz);
      if (d - t.r > m.range) continue;
      if (!full && d > .01 && (fx * dx + fz * dz) / d < Math.cos(m.arc / 2)) continue;
      const dmg = Math.round(m.dmg * mult); t.hit(dmg); this.hud.damage(t.x, p.pos.y + 1.8, t.z, dmg, this.camera);
    }
  }
}
