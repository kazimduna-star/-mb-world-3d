import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// Общий кэш моделей. Геометрия и материалы берутся из оригинальных файлов без изменений.
export class AssetCache {
  constructor() { this.loader = new GLTFLoader(); this.p = new Map(); }
  load(url) {
    if (!this.p.has(url)) this.p.set(url, this.loader.loadAsync(url).then(g => { g.scene.updateMatrixWorld(true); return g; }));
    return this.p.get(url);
  }
  // Один InstancedMesh на каждый меш модели; mats — массив Matrix4 размещений.
  // fit: {h|w|m} — привести модель к размеру в метрах (пропорции сохраняются), центр по XZ, низ на y=0.
  _fit(scene, fit) {
    const m = new THREE.Matrix4(); if (!fit) return m;
    const b = new THREE.Box3().setFromObject(scene), s = b.getSize(new THREE.Vector3()), c = b.getCenter(new THREE.Vector3());
    const k = fit.h ? fit.h / s.y : fit.w ? fit.w / s.x : fit.m ? fit.m / Math.max(s.x, s.z) : 1;
    return m.makeScale(k, k, k).multiply(new THREE.Matrix4().makeTranslation(-c.x, -b.min.y, -c.z));
  }
  // Слияние сотен мешей в несколько (по материалам): меньше draw calls, геометрия и текстуры те же.
  async merged(url, fit) {
    const g = await this.load(url), pre = this._fit(g.scene, fit), by = new Map(), t = new THREE.Matrix4();
    g.scene.traverse(o => {
      if (!o.isMesh) return; let geo = o.geometry.clone();
      for (const k of Object.keys(geo.attributes)) if (!['position', 'normal', 'uv'].includes(k)) geo.deleteAttribute(k);
      if (!geo.attributes.uv) geo.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(geo.attributes.position.count * 2), 2));
      if (!geo.attributes.normal) geo.computeVertexNormals();
      geo.applyMatrix4(t.multiplyMatrices(pre, o.matrixWorld)); if (geo.index) geo = geo.toNonIndexed();
      if (!by.has(o.material)) by.set(o.material, []); by.get(o.material).push(geo);
    });
    return [...by].map(([mat, list]) => { const m = new THREE.Mesh(mergeGeometries(list), mat); m.frustumCulled = false; return m; });
  }
  async instanced(url, mats, fit) {
    const g = await this.load(url), out = [], t = new THREE.Matrix4(), pre = this._fit(g.scene, fit);
    g.scene.traverse(o => {
      if (!o.isMesh) return;
      const m = new THREE.InstancedMesh(o.geometry, o.material, mats.length);
      mats.forEach((p, i) => m.setMatrixAt(i, t.multiplyMatrices(p, pre).multiply(o.matrixWorld)));
      m.castShadow = m.receiveShadow = true; m.frustumCulled = false; m.instanceMatrix.needsUpdate = true; out.push(m);
    });
    return out;
  }
}
