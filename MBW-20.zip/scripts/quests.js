import { CONFIG } from '../config.js';
// Минимальная цепочка заданий этапа 1: проверяет, что управление, взаимодействие и бой работают.
// Полноценная система заданий (меню, награды, главы) — этап 2.
const ruins = CONFIG.zones.find(z => z.id === 'ruins');
const T1 = 'Пробуждение забытого мира', T2 = 'Испытание древнего портала', AR = CONFIG.teleports.arena, PT = CONFIG.zones.find(z => z.id === 'portal');
const STEPS = [
  { title: T1, text: 'Осмотрите древний камень', target: { x: 12, z: -16 }, done: w => w.flags.beacon },
  { title: T1, text: 'Победите тренировочную мишень', target: { x: -10, z: -22 }, done: w => w.flags.dummy },
  { title: T1, text: 'Дойдите до Древних руин', target: { x: ruins.x, z: ruins.z }, done: (w, p) => Math.hypot(p.x - ruins.x, p.z - ruins.z) < 22 },
  { title: T2, text: 'Найдите древний портал', target: { x: PT.x, z: PT.z }, done: (w, p) => Math.hypot(p.x - PT.x, p.z - PT.z) < 14 },
  { title: T2, text: 'Активируйте портал', target: { x: PT.x, z: PT.z }, done: w => w.flags.portalUsed },
  { title: T2, text: 'Победите Аватара Люцифера', target: { x: AR.x, z: AR.z - 8 }, done: w => (w.flags['kill_lucifer-avatar'] || 0) > 0 },
  { title: T2, text: 'Откройте сундук с наградой', target: { x: AR.x, z: AR.z - 17 }, done: w => w.flags.arenaChest },
  { title: T2, text: 'Вернитесь в открытый мир через портал', target: { x: AR.x, z: AR.z + 18 }, done: (w, p) => Math.abs(p.x) < 300 }
];
export class Quests {
  constructor(world, hud) { this.world = world; this.hud = hud; this.i = 0; }
  get title() { return (STEPS[this.i] || STEPS[STEPS.length - 1]).title; }
  current() { return STEPS[this.i] || { text: 'Первый этап пройден. Мир будет расширен в следующих обновлениях', target: null }; }
  update(playerPos) {
    const s = STEPS[this.i]; if (s && s.done(this.world, playerPos)) { this.i++; this.hud.toast('Задание обновлено'); }
  }
}
